package t009.abc;

import t009.ClassA;

class ClassC extends ClassA {
     double d;
}
