package t009.abcc;

public interface InterA {
    public void a();

    public void b();
}
