package t009.abcc;

public interface InterB extends InterA {
}
