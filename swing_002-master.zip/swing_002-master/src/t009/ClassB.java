package t009;

class ClassB extends ClassA{
}
