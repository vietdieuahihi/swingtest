package t013.model;

public class Tank {
    private String path;

    public Tank(String path) {
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
