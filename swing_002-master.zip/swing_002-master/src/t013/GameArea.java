package t013;

public class GameArea {

}
