package t010;

public class A {
    public String mark() {
        return "A";
    }
}
