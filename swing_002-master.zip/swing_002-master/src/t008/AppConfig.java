package t008;

public class AppConfig {
    public static final String AII = "I";
}
