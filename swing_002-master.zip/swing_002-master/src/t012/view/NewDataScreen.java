package t012.view;

import t012.controller.StudentController;

public class NewDataScreen {
    public void a() {
        StudentController a = StudentController.getInstance();
        a.getA();
    }
}
