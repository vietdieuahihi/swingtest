package t012.view;

import t012.controller.StudentController;

public class SplashScreen {
    public void a() {
        StudentController a = StudentController.getInstance();
        a.getA();
        a.setA();
    }
}
