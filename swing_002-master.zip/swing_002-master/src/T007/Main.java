package T007;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
//        String[] a = {null, null, null, "2"};
//        System.out.println(Utils.isEmpty(a));

        String a = "anhpq, dat, nghia, minh";
        char c = 'j';

        System.out.println(Utils.reverse(a));
//        System.out.println(String.valueOf(new Person(28)));
//        System.out.println(a.indexOf("dat"));
//        System.out.println(Arrays.toString(a.split(",", 1)));
//        a.equalsIgnoreCase("asdada");
//        System.out.println(a);
    }
}
